# FunKiiUFrontend
A UI for FunKiiU written in Python

Features:

Multi threaded downloads  
Live search 
Show current downloads  
RSS Feed of title key updates 

![search](https://github.com/christopher-roelofs/FunKiiUFrontend/blob/master/screenshots/search.png "Search")

![Downloads](https://github.com/christopher-roelofs/FunKiiUFrontend/blob/master/screenshots/downloads.png "Downloads")

![Settings](https://github.com/christopher-roelofs/FunKiiUFrontend/blob/master/screenshots/settings.png "Settings")
